// 캔버스에서 동작할 이벤트 정의
const canvas = document.getElementById("jsCanvas")
// MDN으로 캔버스에 그림을 그릴 수 있게 한다.
const ctx = canvas.getContext("2d")
// 색상을 넣어서 그림을 그려보자
const colors = document.getElementsByClassName("jsColor")
// 붓 사이즈 크기를 조절하는 기능 추가
const range = document.getElementById("jsRange")
// 색상을 선택하면 전체 칠하기 버튼으로 바뀌고 전체 칠한다음 다시 원래 버튼으로 되돌아간다.
const mode = document.getElementById("jsMode")
// 그림을 저장하는 저장버튼을 만든다.
const saveBtn = document.getElementById("jsSave")


// 초기화 버튼 생성
const reset = document.getElementById("jsReset")

const INITIAL_COLOR = "#2C2C2C"
const CANVAS_SIZE = 700

ctx.strokeStyle = INITIAL_COLOR
ctx.lineWidth = 2.5
ctx.fillStyle = INITIAL_COLOR
ctx.fillStyle="#FFFFFF"

canvas.width = CANVAS_SIZE
canvas.height = CANVAS_SIZE

let painting = false
let filling = false

function startPainting(){
    painting = true
}

function stopPainting(){
    painting = false
}

function onMouseMove(event) {
    const x = event.offsetX
    const y = event.offsetY
    if(!painting){
        ctx.beginPath()
        ctx.moveTo(x, y)
    } else {
        ctx.lineTo(x,y)
        ctx.stroke()
        //ctx.closePath()
    }
}

/*
function onMouseDown(event){
    painting= true
}

function onMouseUp(event){
    stopPainting()
}
*/

function handleColorClick(event) {
   // console.log(event.target.style)
    const color = event.target.style.backgroundColor
    ctx.strokeStyle = color
    ctx.fillStyle = color
}

function handleRangeChange(event) {
    const size = event.target.value
    ctx.lineWidth = size;
}

function handleModeClick(){
    if(filling === true){
        filling = false
        mode.innerText = "Fill"
    } else {
        filling = true
        mode.innerText="Paint"

    }
}

function handleCanvasClick(){
    if(filling){
        ctx.fillRect(0,0, canvas.width, canvas.height)
    }
  //  ctx.fillRect(0,0, canvas.width, canvas.height)
}

function handleCM(event) {
    event.preventDefault()
}

function handleResetBtn(event) {
    window.location.reload();
}

function handleSaveClick() {
    const image = canvas.toDataURL()
    const link = document.createElement("a")

    link.href = image
    link.download = "PaintJS[🎨]"
    link.click()
}

if(canvas) {
    canvas.addEventListener("mousemove", onMouseMove)
    canvas.addEventListener("mousedown", startPainting)
    canvas.addEventListener("mouseup", stopPainting)
    canvas.addEventListener("mouseleave", stopPainting)
    canvas.addEventListener("click", handleCanvasClick)
    canvas.addEventListener("contextmenu", handleCM)
}
if(colors){
Array.from(colors).forEach(color => 
    color.addEventListener("click", handleColorClick))
}

if(range) {
    range.addEventListener("input", handleRangeChange)
}

if(mode){
    mode.addEventListener("click", handleModeClick)
}

if(saveBtn){
    saveBtn.addEventListener("click", handleSaveClick)
}


if(reset) {
    reset.addEventListener("click", handleResetBtn)
}